%%

BWUsage = 100;
transmit_pic;
visualize_demod;

%%

BWUsage = 50;
transmit_pic;
visualize_demod;